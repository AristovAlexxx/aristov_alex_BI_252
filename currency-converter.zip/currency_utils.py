import requests
import pandas as pd
from bs4 import BeautifulSoup

CBR_URL = "https://www.cbr.ru/currency_base/daily/"

def get_currencies():
    response = requests.get(CBR_URL)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    table = soup.find("table", class_="data")

    df = pd.read_html(str(table))[0]
    df.columns = ["Code", "NumCode", "Nominal", "Currency", "Rate"]
    df["Rate"] = df["Rate"].astype(str).str.replace(",", ".").astype(float)

    rates = {"RUB": 1.0}
    for _, row in df.iterrows():
        rates[row["Code"]] = row["Rate"] / row["Nominal"]

    return rates

def convert_currency(amount, base, target, rates):
    if base not in rates or target not in rates:
        raise ValueError("Unknown currency")
    rub_amount = amount * rates[base]
    return rub_amount / rates[target]
