import streamlit as st
from currency_utils import get_currencies, convert_currency

st.set_page_config(page_title="Currency Converter", page_icon="💱")

st.title("💱 Currency Converter (CBR)")

try:
    rates = get_currencies()
    st.success("Exchange rates successfully loaded from cbr.ru")

    currencies = list(rates.keys())
    base_currency = st.selectbox("From currency:", currencies, index=currencies.index("RUB") if "RUB" in currencies else 0)
    target_currency = st.selectbox("To currency:", currencies, index=currencies.index("USD") if "USD" in currencies else 1)
    amount = st.number_input("Amount:", min_value=0.0, value=100.0, step=0.01)

    if st.button("Convert"):
        result = convert_currency(amount, base_currency, target_currency, rates)
        st.metric(label=f"{amount:.2f} {base_currency} =", value=f"{result:.2f} {target_currency}")
except Exception as e:
    st.error(f"Failed to load data: {e}")
