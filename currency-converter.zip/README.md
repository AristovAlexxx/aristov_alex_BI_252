# 💱 Currency Converter (CBR)

Simple web application built with **Python** and **Streamlit** to convert currencies using current exchange rates from the [Central Bank of Russia](https://cbr.ru/currency_base/daily/).

## 🧩 Features
- Fetches actual rates from cbr.ru
- Conversion between any listed currencies
- Error handling for invalid input or connection issues
- Modular structure (2 Python files)

## ⚙️ Installation

```bash
git clone https://github.com/yourusername/currency-converter.git
cd currency-converter
pip install -r requirements.txt
```

## 🚀 Usage

```bash
streamlit run app.py
```

Then open the local URL printed in your terminal (e.g., http://localhost:8501).
